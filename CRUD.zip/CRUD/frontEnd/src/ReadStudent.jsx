import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

function StudentList() {
  const [students, setStudents] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:8002/student', { studentid, studentname, studentemail})
      .then(res => setStudents(res.data))
      .catch(err => console.log(err));
  }, []);

  return (
    <div>
      <h2>Student List</h2>
      <ul>
        {students.map(student => (
          <li key={student.studentid}>
            <Link to={`/student/${student.studentid}`}>
              {student.studentname}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default StudentList;
