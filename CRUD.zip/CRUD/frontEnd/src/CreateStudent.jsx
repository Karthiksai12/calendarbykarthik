import axios from "axios";
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

function CreateStudent() {
    const [studentid, setstudentid] = useState('');
    const [studentname, setstudentname] = useState('');
    const [studentemail, setstudentemail] = useState('');
    const [validEmail, setValidEmail] = useState(true); // State to track email validation
    
    const navigate = useNavigate();

    function handleSubmit(event) {
        event.preventDefault();
        // Check if email is valid before submitting
        if (!validEmail) return;
        
        axios.post('http://localhost:8002/student', { studentid, studentname, studentemail})
            .then(res => {
                console.log(res);
                navigate('/');
            })
            .catch(err => console.error(err));
    }

    // Function to validate email using regular expression
    const validateEmail = (email) => {
        // Regular expression for email validation
        const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return regex.test(email);
    };

    // Function to handle email input change and validate email
    const handleEmailChange = (e) => {
        const email = e.target.value;
        setstudentemail(email); // Update studentemail state
        setValidEmail(validateEmail(email)); // Update validEmail state based on email validity
    };

    return (
        <div className="d-flex vh-100 bg-primary justify-content-center align-items-center">
            <div className="w-50 bg-white rounded p-3">
                <form onSubmit={handleSubmit}>
                    <h2>Add New Student</h2>
                    <div className="mb-2">
                        <input 
                            type="text" 
                            id="dept" 
                            placeholder="Enter id" 
                            className="form-control"
                            value={studentid}
                            onChange={e => setstudentid(e.target.value)}
                        />
                    </div>
                    <div className="mb-2">
                        <input 
                            type="text" 
                            id="Name" 
                            placeholder="Enter name" 
                            className="form-control"
                            value={studentname}
                            onChange={e => setstudentname(e.target.value)}
                        />
                    </div>
                    <div className="mb-2">
                        <input 
                            type="text" 
                            id="email" 
                            placeholder="Enter email" 
                            className={`form-control ${validEmail ? '' : 'is-invalid'}`} // Add 'is-invalid' class if email is not valid
                            value={studentemail}
                            onChange={handleEmailChange} // Use handleEmailChange instead of directly setting studentemail
                        />
                        {!validEmail && <div className="invalid-feedback">Please enter a valid email address.</div>} {/* Display validation message if email is not valid */}
                    </div>
                    <button className="btn btn-success">Submit</button>
                </form>
            </div>
        </div>
    );
}

export default CreateStudent;
