import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

function Home() {
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    axios.get('http://localhost:8002/')
      .then(res => {
        setStudents(res.data);
        setLoading(false);
      })
      .catch(err => console.log(err));
  }, []);

  const handleDelete = async (studentid) => {
    try {
      await axios.delete(`http://localhost:8002/student/${studentid}`);
      // Update state to remove the deleted student
      setStudents(students.filter(student => student.studentid !== studentid));
    } catch (err) {
      console.log(err);
    }
  };

  return (
    <div className='d-flex vh-100 bg-primary justify-content-center align-items-center'>
      <div className='w-50 bg-white rounded p-3'>
        <div className="d-flex justify-content-end mb-3">
          <Link to='/Create' className='btn btn-success'>Add+</Link>
        </div>
        {loading ? (
          <p>Loading...</p>
        ) : students.length === 0 ? (
          <p>No students found</p>
        ) : (
          <table className='table'>
            <thead>
              <tr>
                <th>Student ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {students.map(student => (
                <tr key={student.studentid}>
                  <td>{student.studentid}</td>
                  <td>{student.studentname}</td>
                  <td>{student.studentemail}</td>
                  <td>
                    
                    <Link to={`update/${student.studentid}`} className='btn btn-primary'>Update</Link>
                    <button onClick={() => handleDelete(student.studentid)} className='btn btn-danger ms-2'>Delete</button>
                    
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

export default Home;
