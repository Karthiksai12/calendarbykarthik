import React, { useState } from 'react';

function Calendar() {
  const [currentDate, setCurrentDate] = useState(new Date()); // Automatically sets to current date
  const [selectedDate, setSelectedDate] = useState(null);
  const [tasks, setTasks] = useState({}); // Map of dates with tasks assigned
  const [clickedDates, setClickedDates] = useState([]); // Array to store clicked dates
  const [hoveredDate, setHoveredDate] = useState(null); // Track hovered date

  const handlePrevMonth = () => {
    setCurrentDate(prevDate => {
      const prevMonthDate = new Date(prevDate);
      prevMonthDate.setMonth(prevMonthDate.getMonth() - 1);
      return prevMonthDate;
    });
  };

  const handleNextMonth = () => {
    setCurrentDate(prevDate => {
      const nextMonthDate = new Date(prevDate);
      nextMonthDate.setMonth(nextMonthDate.getMonth() + 1);
      return nextMonthDate;
    });
  };

  const handleTaskAssigned = (day) => {
    const dateString = new Date(currentDate.getFullYear(), currentDate.getMonth(), day).toDateString();
    setTasks(prevTasks => ({ ...prevTasks, [dateString]: true }));
    setClickedDates([...clickedDates, day]); // Add clicked date to the array
  };

  const handleTaskNotAssigned = (day) => {
    const dateString = new Date(currentDate.getFullYear(), currentDate.getMonth(), day).toDateString();
    const updatedTasks = { ...tasks };
    delete updatedTasks[dateString];
    setTasks(updatedTasks);
    setClickedDates([...clickedDates, day]); // Add clicked date to the array
  };

  const handleMouseEnter = (day) => {
    setHoveredDate(day);
  };

  const handleMouseLeave = () => {
    setHoveredDate(null);
  };

  const daysInMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0).getDate();
  const startDayOfWeek = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1).getDay();
  let calendarRows = [];
  let row = [];

  for (let i = 0; i < startDayOfWeek; i++) {
    row.push(<td key={`empty-${i}`}></td>);
  }

  for (let day = 1; day <= daysInMonth; day++) {
    if (row.length === 7) {
      calendarRows.push(<tr key={day}>{row}</tr>);
      row = [];
    }
    const isCurrentDate = day === currentDate.getDate();
    const isSelectedDate = selectedDate && selectedDate.getDate() === day;
    const dateString = new Date(currentDate.getFullYear(), currentDate.getMonth(), day).toDateString();
    const isTaskAssigned = tasks[dateString];
    const isClickedDate = clickedDates.includes(day); // Check if the date has been clicked
    const isHovered = hoveredDate === day; // Check if the date is currently hovered

    let className;

    if (isTaskAssigned) {
      className = isCurrentDate ? "bg-danger text-white" : isSelectedDate ? "bg-primary text-white" : "bg-success text-white";
    } else {
      className = isCurrentDate ? "bg-primary text-white" : isSelectedDate ? "bg-primary text-white" : "bg-info text-white";
    }

    if (isClickedDate) {
      className = isTaskAssigned ? "bg-success text-white" : "bg-danger text-white"; // Change color to green if task assigned, red otherwise
    }

    row.push(
      <td
        key={day}
        className={className}
        style={{ 
          cursor: 'pointer', 
          width: '10%', 
          height: '120px', 
          position: 'relative', 
          transition: 'background-color 0.3s', // Add transition for smooth color change
          textAlign: 'center', // Center the text
          verticalAlign: 'middle', // Align text vertically
        }}
        onMouseEnter={() => handleMouseEnter(day)}
        onMouseLeave={handleMouseLeave}
      >
        <div>{day}</div>
        {isHovered && !isClickedDate ? (
          <div style={{ display: 'flex', justifyContent: 'space-around', marginTop: '5px' }}>
            <button onClick={() => handleTaskAssigned(day)} className="btn btn-success btn-sm">Assigned</button>
            <button onClick={() => handleTaskNotAssigned(day)} className="btn btn-danger btn-sm">Not Assigned</button>
          </div>
        ) : null}
      </td>
    );
  }

  while (row.length < 7) {
    row.push(<td key={`empty-${row.length}`}></td>);
  }

  calendarRows.push(<tr key="lastRow">{row}</tr>);

  return (
    <div className="container-fluid mt-5 d-flex justify-content-center">
      <div className="card shadow" style={{ height: '150%', width: '70%' }}>
        <div className="card-header bg-primary text-white" style={{ fontSize: '3rem' }}>
          <div className="row align-items-center">
            <div className="col-md-2 text-end" onClick={handlePrevMonth}>
              <span role="button" aria-label="Previous month" style={{ cursor: 'pointer', fontSize: '3rem', color: 'white' }}>«</span>
            </div>
            <div className="col-md-8 text-center">
              <h5 className="card-title" style={{ cursor: 'pointer', margin: '0' }}>{currentDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}</h5>
            </div>
            <div className="col-md-2 text-start" onClick={handleNextMonth}>
              <span role="button" aria-label="Next month" style={{ cursor: 'pointer', fontSize: '3rem', color: 'white' }}>»</span>
            </div>
          </div>
        </div>
        <div className="card-body align-items-center">
          <table className="table table-bordered">
            <thead>
              <tr>
                <th style={{ height: '50px', textAlign: 'center' }}>Sun</th>
                <th style={{ height: '50px', textAlign: 'center' }}>Mon</th>
                <th style={{ height: '50px', textAlign: 'center' }}>Tue</th>
                <th style={{ height: '50px', textAlign: 'center' }}>Wed</th>
                <th style={{ height: '50px', textAlign: 'center' }}>Thu</th>
                <th style={{ height: '50px', textAlign: 'center' }}>Fri</th>
                <th style={{ height: '50px', textAlign: 'center' }}>Sat</th>
              </tr>
            </thead>
            <tbody>
              {calendarRows}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export default Calendar;
