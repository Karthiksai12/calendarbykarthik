import axios from "axios";
import React, { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";

function UpdateStudent() {
    const [studentid, setstudentid] = useState('');
    const [studentname, setstudentname] = useState('');
    const [studentemail, setstudentemail] = useState('');
    const { id } = useParams();
    const navigate = useNavigate();

    useEffect(() => {

        axios.get(`http://localhost:8002/student/${id}`)
            .then(res => {
                const { studentid,setstudentname,studentemail } = res.data;
                setstudentid(studentid);
                setstudentname(studentname);
                setstudentemail(studentemail);
            })
            .catch(err => console.error(err));
    }, [id]);

    function handleSubmit(event) {
        event.preventDefault();
        axios.put(`http://localhost:8002/student/${id}`, { studentid,studentname,studentemail })
            .then(res => {
                console.log(res);
                navigate('/');
            })
            .catch(err => console.error(err));
    }

    return (
        <div className="d-flex vh-100 bg-primary justify-content-center align-items-center">
            <div className="w-50 bg-white rounded p-3">
                <form onSubmit={handleSubmit}>
                    <h2>Update student</h2>
                    <div className="mb-2">
                        <input 
                            type="text" 
                            id="dept" 
                            placeholder="studentid" 
                            className="form-control"
                            value={studentid}
                            onChange={e => setstudentid(e.target.value)}
                        />
                    </div>
                    <div className="mb-2">
                        <input 
                            type="text" 
                            id="Name" 
                            placeholder="Enter name" 
                            className="form-control"
                            value={studentname}
                            onChange={e => setstudentname(e.target.value)}
                        />
                    </div>
                    <div className="mb-2">
                        <input 
                            type="text" 
                            id="email" 
                            placeholder="Enter email" 
                            className="form-control"
                            value={studentemail}
                            onChange={e => setstudentemail(e.target.value)}
                        />
                    </div>
                    <button className="btn btn-success">Update</button>
                </form>
            </div>
        </div>
    );
}

export default UpdateStudent;
