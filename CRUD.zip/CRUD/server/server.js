import express from "express";
import mysql from "mysql";
import bodyParser from "body-parser";
import cors from 'cors'

const app = express();
app.use(cors());
app.use(bodyParser.json());

const db = mysql.createConnection({
    host: "localhost",
    user: "root",
    port: "3306",
    password: "password",
    database: "crud"
});


db.connect((err) => {
    if (err) {
        console.error('Database connection failed: ' + err.stack);
        return;
    }
    console.log('Connected to database.');
});

// get operation

app.get('/', (req, res) => {
    const sql = "SELECT * FROM student";
    db.query(sql, (err, result) => {
        if (err) return res.json({ message: err });
        return res.json(result);
    });
});

// put operation

app.put('/student/:studentid', (req, res) => {
    const { studentid} = req.params;
    const { studentname,studentemail } = req.body;

    if (! studentid || !studentname || !studentemail) {
        return res.status(400).json({ message: 'Missing fields in request body' });
    }

    const sql = "UPDATE student SET studentid = ?, studentname = ?, studentemail = ?";
    db.query(sql, [studentid,studentname,studentemail], (err, result) => {
        if (err) {
            console.error(err);
            return res.json({ message: err });
        }
        return res.json({ message: ' updated successfully', result });
    });
});

//post operation

app.post('/student', (req, res) => {
    const { studentid,studentname,studentemail } = req.body;
    if (!studentid || !studentname || !studentemail) {
        return res.status(400).json({ message: 'All fields (studentid,studentname,studentemail) are required' });
    }
    
    const sql = "INSERT INTO student (studentid,studentname,studentemail) VALUES (?, ?, ?)";
    db.query(sql, [studentid,studentname,studentemail], (err, result) => {
        if (err) {
            console.error(err);
            return res.json({ message: err });
        }
        return res.json({ message: 'data added successfully', result });
    });
});


//delete opeartion


app.delete('/student/:studentid', (req, res) => {
    const { studentid } = req.params;
    const sql = "DELETE FROM student WHERE studentid = ?"; // <- Corrected column name
    db.query(sql, [studentid], (err, result) => {
        if (err) return res.json({ message: err });
        return res.json({ message: 'data deleted successfully', result });
    });
});


app.listen(8002, () => {
    console.log("heyaa");
});
